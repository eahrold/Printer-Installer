//
//  NSString+NSData.h
//  Server
//
//  Created by Eldon on 11/5/13.
//  Copyright (c) 2013 Eldon Ahrold. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NSData)
+(NSString*)stringWithData:(NSData*)data;

@end
